//
//  FlowerIDApp.swift
//  FlowerID
//
//  Created by Nabeel on 08/04/23.
//

import SwiftUI

@main
struct FlowerIDApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
